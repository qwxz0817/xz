#include "Lattice.hpp"
#include "IsingSystem.hpp"

int main(int argc, char** argv) {
    /* Honeycomb lattice system (brute-force exact counting) */
    const int dim = 2;
    std::vector<int> L(dim);
    const int L_default = 2;
    L[0] = argc > 1 ? std::atoi(argv[1]) : L_default;
    if (L[0] <= 0) L[0] = L_default;
    L[1] = L[0];
    const int n_spins = HoneycombLatticeIsingSystem::eval_n_spins(L);

    const double Tmin = 0.1;
    const double Tdlt = 0.1;
    const double Tupb = 3.5;
    const int nT = std::floor((Tupb - Tmin) / Tdlt) + 1;
    std::vector<double> beta(nT);
    for (int i = 0; i < nT; i++) beta[i] = 1.0 / (Tmin + i * Tdlt);

    HoneycombLatticeDataBundle data_bundle(n_spins, beta);
    HoneycombLatticeIsingSystem system(L, data_bundle);
    system.exact_count();

    data_bundle.output_legends_exact(system._system_size());
    data_bundle.output_data_exact_all();

    return 0;
}
