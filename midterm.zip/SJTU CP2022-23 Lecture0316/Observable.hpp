#ifndef Observable_hpp
#define Observable_hpp

#include <cmath>
#include <vector>
#include <iostream>
#include <numeric>

class Observable {
private:
	double q;
	double q_abs;
	double q_sq;
	double q_quar;
	double q_fluc;
	
	double Z_thermal;
	
public:
	Observable() : q(0), q_abs(0), q_sq(0), q_quar(0), q_fluc(0), Z_thermal(0) {};
	~Observable() {};
	
	double _q() const { return q; };
	double _q_abs() const { return q_abs; };
	double _q_sq() const { return q_sq; };
	double _q_quar() const { return q_quar; };
	double _q_fluc() const { return q_fluc;	};
	double eval_q_fluc() {
		q_fluc = q_sq - q * q;
		return q_fluc;
	};
	
	void update_direct_by(const double& x, const double& weight) {
		q += x * weight;
		q_abs += std::fabs(x) * weight;
		const double sq = x * x;
		q_sq += sq * weight;
		q_quar += sq * sq * weight;
		Z_thermal += weight;
	};
	
	void weight_correction_by(const double& w) {
		q *= w;
		q_abs *= w;
		q_sq *= w;
		q_quar *= w;
		Z_thermal *= w;
	};
	
	void normalize_by_Z() {
		q /= Z_thermal;
		q_abs /= Z_thermal;
		q_sq /= Z_thermal;
		q_quar /= Z_thermal;
		eval_q_fluc();
	}
};

class DataBundle {
protected:
	const int n_spins;
	const std::vector<double> beta;
	std::vector<Observable> exact_energy;
	std::vector<Observable> exact_magz;

public:
	DataBundle(const int n_spins_spec, const std::vector<double>& beta_spec) : n_spins(n_spins_spec), beta(DataBundle::eval_sorted_beta(beta_spec)), exact_energy(beta_spec.size()), exact_magz(beta_spec.size()) {};
	
	~DataBundle() {};
	
	std::vector<double> _beta() const { return beta; };
	
	double _beta(int beta_idx) const { return beta[beta_idx]; };
	
	double eval_T(int beta_idx) const { return 1.0 / beta[beta_idx]; };
	
	double _get_exact_energy(unsigned int beta_idx) const {
		return exact_energy.at(beta_idx)._q();
	};
	double _get_exact_energy_per_spin(unsigned int beta_idx) const {
		return _get_exact_energy(beta_idx) / n_spins;
	};
	
	double _get_exact_C(unsigned int beta_idx) const {
		return _beta(beta_idx) * _beta(beta_idx) * exact_energy.at(beta_idx)._q_fluc();
	};
	double _get_exact_C_per_spin(unsigned int beta_idx) const {
		return _get_exact_C(beta_idx) / n_spins;
	};
	
	double _get_exact_magz(unsigned int beta_idx) const {
		return exact_magz.at(beta_idx)._q();
	};
	double _get_exact_magz_per_spin(unsigned int beta_idx) const {
		return _get_exact_magz(beta_idx) / n_spins;
	};
	
	double _get_exact_magz_sq(unsigned int beta_idx) const {
		return exact_magz.at(beta_idx)._q_sq();
	};
	double _get_exact_magz_sq_per_spin(unsigned int beta_idx) const {
		return _get_exact_magz_sq(beta_idx) / eval_n_spins_sq();
	};
	
protected:
	static std::vector<double> eval_sorted_beta(std::vector<double> b) {
		std::sort(b.begin(), b.end());
		return b;
	};
	
	int eval_n_spins_sq() const {
		return n_spins * n_spins;
	};
};

class SquareLatticeDataBundle : public DataBundle {
	friend class SquareLatticeIsingSystem;

public:
	SquareLatticeDataBundle(int n_spins_spec, const std::vector<double>& beta_spec) : DataBundle(n_spins_spec, beta_spec) {};
	
	~SquareLatticeDataBundle() {};
	
	void output_legends_exact(const std::string system_size) {
		std::cout << system_size << std::endl;
		std::cout << "# T[1] E[2] C[3] M[4] M^2[5]" << std::endl;
	};
	
	void output_data_exact(int beta_idx) {
		std::cout << eval_T(beta_idx) << ' ';
		std::cout << _get_exact_energy_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_C_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_magz_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_magz_sq_per_spin(beta_idx) << ' ';
		std::cout << std::endl;
	};
	
	void output_data_exact_all() {
		for ( unsigned int beta_idx = 0; beta_idx < beta.size(); beta_idx++ ) {
			output_data_exact(beta_idx);
		}
	};
};
class HoneycombLatticeDataBundle : public DataBundle {
	friend class HoneycombLatticeIsingSystem;

public:
	HoneycombLatticeDataBundle(int n_spins_spec, const std::vector<double>& beta_spec) : DataBundle(n_spins_spec, beta_spec) {};

	~HoneycombLatticeDataBundle() {};

	void output_legends_exact(const std::string system_size) {
		std::cout << system_size << std::endl;
		std::cout << "# T[1] E[2] C[3] M[4] M^2[5]" << std::endl;
	};

	void output_data_exact(int beta_idx) {
		std::cout << eval_T(beta_idx) << ' ';
		std::cout << _get_exact_energy_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_C_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_magz_per_spin(beta_idx) << ' ';
		std::cout << _get_exact_magz_sq_per_spin(beta_idx) << ' ';
		std::cout << std::endl;
	};

	void output_data_exact_all() {
		for (unsigned int beta_idx = 0; beta_idx < beta.size(); beta_idx++) {
			output_data_exact(beta_idx);
		}
	};
};



#endif /* Observable_hpp */
