#ifndef IsingSystem_hpp
#define IsingSystem_hpp

#include <iostream>
#include <vector>
#include <cmath>
#include "Lattice.hpp"
#include "Observable.hpp"

class IsingSpin {
private:
	int sz; /* +/- 1 */

public:
	IsingSpin() {	sz = 1; };

	~IsingSpin() {};

	int _sz() const { return sz; };

	void set_sz(int sz_spec) {
		assert(sz_spec == 1 || sz_spec == -1);
		sz = sz_spec;
	};

	void flip() {	sz *= -1; };
};

class IsingSystem {
protected:
	const double J;
	const int n_spins;
	std::vector<IsingSpin> spin;
	const long long maxrep_state;
	
public:
	IsingSystem(const int n_spins_spec)
	: J(-1.0), n_spins(n_spins_spec), maxrep_state(static_cast<long long>(std::pow(2, n_spins)) - 1)	{
		spin.resize(n_spins);
	};

	virtual ~IsingSystem() {};

	double _J() const { return J; };
	
	int _n_spins() const { return n_spins; };
	
	int _sz(const int site_idx) const { return spin[site_idx]._sz(); }
	
	void set_spin(const int site_idx, int s_spec) {	spin[site_idx].set_sz(s_spec); };
	
	void flip_spin(const int site_idx) { spin[site_idx].flip(); };
	
	double eval_mz() const {
		int mz_tmp = 0;
		for (int site_idx = 0; site_idx < n_spins; site_idx++) {
			mz_tmp += spin[site_idx]._sz();
		}
		return static_cast<double>(mz_tmp);
	};
	
	long long _maxrep_state() const { return maxrep_state; };
	
	void set_state_by_code(long long rep_state) {
		assert(rep_state >= 0 && rep_state <= maxrep_state);
		for (int site_idx = 0; site_idx < n_spins; site_idx++) {
			set_spin(site_idx, (rep_state % 2) ? 1 : -1);
			rep_state /= 2;
		}
	}
};

class SquareLatticeIsingSystem : public IsingSystem {
private:
	SquareLattice lattice;
	SquareLatticeDataBundle* ptrMCDB;
	const int beta_list_size;

public:
	SquareLatticeIsingSystem(const std::vector<int>& L_spec, SquareLatticeDataBundle& MCDB_spec)
	: IsingSystem(SquareLatticeIsingSystem::eval_n_spins(L_spec)),
	lattice(L_spec), ptrMCDB(&MCDB_spec), beta_list_size(static_cast<unsigned int>(MCDB_spec._beta().size())) {};
	
	SquareLatticeIsingSystem(const std::vector<int>& L_spec)
	: IsingSystem(SquareLatticeIsingSystem::eval_n_spins(L_spec)), lattice(L_spec), ptrMCDB(nullptr), beta_list_size(0) {};

	~SquareLatticeIsingSystem() { ptrMCDB = nullptr; };

	int _L0() const { return lattice._L0(); };
	int _L1() const { return lattice._L1(); };
	std::string _system_size() const { return "# System size : " + std::to_string(_L0()) + " x " + std::to_string(_L1()); };
	
	double _beta(int beta_idx) const {
		assert(ptrMCDB != (DataBundle* const)(NULL));
		assert(beta_idx >= 0 && beta_idx < beta_list_size);
		return ptrMCDB->_beta(beta_idx);
	};

	void exact_count() {
		assert(ptrMCDB != (DataBundle* const)(NULL));
		double ene, mz, weight;
		long long rep_state = 0;
		double ene_min = 0;
		while (rep_state <= maxrep_state) {
			set_state_by_code(rep_state);
			ene = eval_energy();
			mz = eval_mz();
			
			if (ene < ene_min) { /* weight correction */
				const double dE = ene_min - ene;
				for ( int beta_idx = 0; beta_idx < beta_list_size; beta_idx++ ) {
					const double w_correction = std::exp(-ptrMCDB->_beta(beta_idx) * dE);
					ptrMCDB->exact_energy[beta_idx].weight_correction_by(w_correction);
					ptrMCDB->exact_magz[beta_idx].weight_correction_by(w_correction);
				}
				ene_min = ene;
			}

			for ( int beta_idx = 0; beta_idx < beta_list_size; beta_idx++ ) {
				weight = std::exp(-ptrMCDB->_beta(beta_idx) * (ene - ene_min));
				ptrMCDB->exact_energy[beta_idx].update_direct_by(ene, weight);
				ptrMCDB->exact_magz[beta_idx].update_direct_by(mz, weight);
			}
			
			rep_state++;
		}
		
		for ( int beta_idx = 0; beta_idx < beta_list_size; beta_idx++ ) {
			ptrMCDB->exact_energy[beta_idx].normalize_by_Z();
			ptrMCDB->exact_magz[beta_idx].normalize_by_Z();
		}
	};
	
	double eval_energy() const {
		double energy_tmp = 0;
		
		const int z_half =  lattice._z_common_half();
		for (int site_idx = 0; site_idx < lattice._N_sites(); site_idx++) {
			for (int bond_index = 0; bond_index < z_half; bond_index++) {
				const int j = lattice._NN_of_Site(site_idx, bond_index);
				energy_tmp += J * spin[site_idx]._sz() * spin[j]._sz();
			}
		}
		
		return energy_tmp;
	};
	
	static int eval_n_spins(const std::vector<int>& L_spec) {
		return L_spec.at(0) * L_spec.at(1);
	};
};


class HoneycombLatticeIsingSystem : public IsingSystem {
private:
	HoneycombLattice lattice;
	HoneycombLatticeDataBundle* ptrMCDB;
	const int beta_list_size;

public:
	HoneycombLatticeIsingSystem(const std::vector<int>& L_spec, HoneycombLatticeDataBundle& MCDB_spec)
		: IsingSystem(HoneycombLatticeIsingSystem::eval_n_spins(L_spec)),
		lattice(L_spec), ptrMCDB(&MCDB_spec), beta_list_size(static_cast<unsigned int>(MCDB_spec._beta().size())) {};

	HoneycombLatticeIsingSystem(const std::vector<int>& L_spec)
		: IsingSystem(HoneycombLatticeIsingSystem::eval_n_spins(L_spec)), lattice(L_spec), ptrMCDB(nullptr), beta_list_size(0) {};

	~HoneycombLatticeIsingSystem() { ptrMCDB = nullptr; };

	int _L0() const { return lattice._L0(); };
	int _L1() const { return lattice._L1(); };
	std::string _system_size() const { return "# System size : " + std::to_string(_L0()) + " x " + std::to_string(_L1()); };

	double _beta(int beta_idx) const {
		assert(ptrMCDB != (DataBundle* const)(NULL));
		assert(beta_idx >= 0 && beta_idx < beta_list_size);
		return ptrMCDB->_beta(beta_idx);
	};

	void exact_count() {
		assert(ptrMCDB != (DataBundle* const)(NULL));
		double ene, mz, weight;
		long long rep_state = 0;
		double ene_min = 0;
		while (rep_state <= maxrep_state) {
			set_state_by_code(rep_state);
			ene = eval_energy();
			mz = eval_mz();

			if (ene < ene_min) { /* weight correction */
				const double dE = ene_min - ene;
				for (int beta_idx = 0; beta_idx < beta_list_size; beta_idx++) {
					const double w_correction = std::exp(-ptrMCDB->_beta(beta_idx) * dE);
					ptrMCDB->exact_energy[beta_idx].weight_correction_by(w_correction);
					ptrMCDB->exact_magz[beta_idx].weight_correction_by(w_correction);
				}
				ene_min = ene;
			}

			for (int beta_idx = 0; beta_idx < beta_list_size; beta_idx++) {
				weight = std::exp(-ptrMCDB->_beta(beta_idx) * (ene - ene_min));
				ptrMCDB->exact_energy[beta_idx].update_direct_by(ene, weight);
				ptrMCDB->exact_magz[beta_idx].update_direct_by(mz, weight);
			}

			rep_state++;
		}

		for (int beta_idx = 0; beta_idx < beta_list_size; beta_idx++) {
			ptrMCDB->exact_energy[beta_idx].normalize_by_Z();
			ptrMCDB->exact_magz[beta_idx].normalize_by_Z();
		}
	};


	double eval_energy() const {
		double energy_tmp = 0;

		const int z_half = lattice._z_common_half();
		for (int site_idx = 0; site_idx < lattice._N_sites(); site_idx++) {
			for (int bond_index = 0; bond_index < z_half; bond_index++) {
				const int j = lattice._NN_of_Site(site_idx, bond_index);
				energy_tmp += J * spin[site_idx]._sz() * spin[j]._sz();
			}
		}

		return energy_tmp;
	};

	static int eval_n_spins(const std::vector<int>& L_spec) {
		return L_spec.at(0) * L_spec.at(1) * 2;
	};
};


#endif /* IsingSystem_hpp */
