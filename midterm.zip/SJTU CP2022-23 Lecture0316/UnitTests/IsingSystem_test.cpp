#include "catch2/catch_amalgamated.hpp"
#include "../IsingSystem.hpp"

TEST_CASE("IsingSpin") {
	IsingSpin test_spin;
	REQUIRE(test_spin._sz() == 1);

	test_spin.set_sz(-1);
	REQUIRE(test_spin._sz() == -1);
	
	test_spin.flip();
	REQUIRE(test_spin._sz() == 1);
}

TEST_CASE("IsingSystem") {
	const int n_spins = 4;
	IsingSystem test_system(n_spins);
	REQUIRE(test_system._J() == -1);
	
	REQUIRE(test_system._sz(0) == 1);
	REQUIRE(test_system._sz(1) == 1);
	REQUIRE(test_system._sz(2) == 1);
	REQUIRE(test_system._sz(3) == 1);
	REQUIRE(test_system.eval_mz() == 4.0);
	
	test_system.flip_spin(0);
	REQUIRE(test_system._sz(0) == -1);
	REQUIRE(test_system.eval_mz() == 2.0);
	
	test_system.set_spin(2, -1);
	REQUIRE(test_system._sz(2) == -1);
	REQUIRE(test_system.eval_mz() == 0.0);
	
	test_system.set_spin(3, -1);
	REQUIRE(test_system._sz(3) == -1);
	REQUIRE(test_system.eval_mz() == -2.0);
}

TEST_CASE("SquareLatticeIsingSystem") {
	const int dim = 2;
	std::vector<int> L(dim);
	L[0] = 4;
	L[1] = 4;
	SquareLatticeIsingSystem test_system(L);
	REQUIRE(test_system._n_spins() == 16);
	REQUIRE(test_system.eval_energy() == -32.0);
	REQUIRE(test_system.eval_mz() == 16.0);
}

TEST_CASE("SquareLatticeIsingSystem 2") {
	const int dim = 2;
	std::vector<int> L(dim);
	L[0] = 4;
	L[1] = 3;
	SquareLatticeIsingSystem test_system(L);
	test_system.set_spin(2, -1);
	test_system.set_spin(6, -1);
	test_system.set_spin(7, -1);
	test_system.set_spin(9, -1);
	test_system.set_spin(11, -1);
	
	REQUIRE(test_system._n_spins() == 12);
	REQUIRE(test_system.eval_energy() == 4.0);
	REQUIRE(test_system.eval_mz() == 2.0);
}

TEST_CASE("IsingSystem Int. Rep. of States (1)") {
	const int n_spins = 12;
	IsingSystem test_system(n_spins);
	test_system.set_state_by_code(1339);
	REQUIRE(test_system._sz(0) == 1);
	REQUIRE(test_system._sz(1) == 1);
	REQUIRE(test_system._sz(2) == -1);
	REQUIRE(test_system._sz(3) == 1);
	REQUIRE(test_system._sz(4) == 1);
	REQUIRE(test_system._sz(5) == 1);
	REQUIRE(test_system._sz(6) == -1);
	REQUIRE(test_system._sz(7) == -1);
	REQUIRE(test_system._sz(8) == 1);
	REQUIRE(test_system._sz(9) == -1);
	REQUIRE(test_system._sz(10) == 1);
	REQUIRE(test_system._sz(11) == -1);
}

TEST_CASE("SquareLatticeIsingSystem Integer Rep. of States (2)") {
	const int dim = 2;
	std::vector<int> L(dim);
	L[0] = 2;
	L[1] = 2;
	SquareLatticeIsingSystem test_system(L);
	REQUIRE(test_system._maxrep_state() == 15);
	
	test_system.set_state_by_code(0);
	REQUIRE(test_system.eval_mz() == -4.0);
	REQUIRE(test_system.eval_energy() == -8.0);
	
	test_system.set_state_by_code(1);
	REQUIRE(test_system.eval_mz() == -2.0);
	REQUIRE(test_system.eval_energy() == 0.0);

	test_system.set_state_by_code(2);
	REQUIRE(test_system.eval_mz() == -2.0);
	REQUIRE(test_system.eval_energy() == 0.0);

	test_system.set_state_by_code(3);
	REQUIRE(test_system.eval_mz() == 0.0);
	REQUIRE(test_system.eval_energy() == 0.0);

	test_system.set_state_by_code(15);
	REQUIRE(test_system.eval_mz() == 4.0);
	REQUIRE(test_system.eval_energy() == -8.0);
}

TEST_CASE("SquareLatticeIsingSystem setup") {
	const int dim = 2;
	std::vector<int> L(dim);
	L[0] = 4;
	L[1] = 3;
	SquareLatticeIsingSystem test_system(L);
	test_system.set_state_by_code(1339);
	REQUIRE(test_system._sz(0) == 1);
	REQUIRE(test_system._sz(1) == 1);
	REQUIRE(test_system._sz(2) == -1);
	REQUIRE(test_system._sz(3) == 1);
	REQUIRE(test_system._sz(4) == 1);
	REQUIRE(test_system._sz(5) == 1);
	REQUIRE(test_system._sz(6) == -1);
	REQUIRE(test_system._sz(7) == -1);
	REQUIRE(test_system._sz(8) == 1);
	REQUIRE(test_system._sz(9) == -1);
	REQUIRE(test_system._sz(10) == 1);
	REQUIRE(test_system._sz(11) == -1);
	REQUIRE(test_system.eval_energy() == 4.0);
	REQUIRE(test_system.eval_mz() == 2.0);
}

TEST_CASE("SquareLatticeIsingSystem Observables Brute-Force Counting") {
	const int dim = 2;
	std::vector<int> L(dim);
	L[0] = 2;
	L[1] = 2;
	const int n_spins = SquareLatticeIsingSystem::eval_n_spins(L);
	const std::vector<double> beta{ 0, 0.3, 1.1, 10.1, 100.1 };
	SquareLatticeDataBundle data_bundle(n_spins, beta);
	SquareLatticeIsingSystem test_system(L, data_bundle);
	test_system.exact_count();
	
	const double Jabs = std::fabs(test_system._J());
	const double mz = 0.0;
	for ( unsigned int beta_idx = 0; beta_idx < beta.size(); beta_idx++ ) {
		const double b = beta[beta_idx];
		const double mz_sq = 16.0 * (1.0 + std::exp(-8.0 * b * Jabs)) / (6.0 * std::exp(-8.0 * b * Jabs) + (1.0 + std::exp(-16.0 * b * Jabs)));
		const double energy = -8.0 * (1.0 - std::exp(-16.0 * b * Jabs)) / (6.0 * std::exp(-8.0 * b * Jabs) + (1.0 + std::exp(-16.0 * b * Jabs)));
		const double ene_sq = 64.0 * (1.0 + std::exp(-16.0 * b * Jabs)) / (6.0 * std::exp(-8.0 * b * Jabs) + (1.0 + std::exp(-16.0 * b * Jabs)));
		
		REQUIRE_THAT(data_bundle._get_exact_magz(beta_idx), Catch::Matchers::WithinRel(mz, 1e-12));
		REQUIRE_THAT(data_bundle._get_exact_magz_sq(beta_idx), Catch::Matchers::WithinRel(mz_sq, 1e-12));
		REQUIRE_THAT(data_bundle._get_exact_energy(beta_idx), Catch::Matchers::WithinRel(energy, 1e-12));
		REQUIRE_THAT(data_bundle._get_exact_C(beta_idx), Catch::Matchers::WithinRel(b * b * (ene_sq - energy * energy), 1e-12));
	}
}
